package dev.cosmicserenity.planetrender;

import net.neoforged.fml.common.Mod;

@Mod(BytsnPlanetRenderMod.MOD_ID)
public final class BytsnPlanetRenderMod {
    public static final String MOD_ID = "bytsn_planet_render";

    public BytsnPlanetRenderMod() {
        // The companion is data-driven. Client rendering is registered by PlanetSkyRenderer.
    }
}
