package dev.cosmicserenity.planetrender.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.OverlayTexture;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@EventBusSubscriber(modid = "bytsn_planet_render", value = Dist.CLIENT)
public final class PlanetSkyRenderer {
    private static final ResourceKey<Level> SPACE_DIMENSION = ResourceKey.create(
            Registries.DIMENSION,
            ResourceLocation.fromNamespaceAndPath("bytsn_planet_render", "space")
    );
    private static final String DATA_FOLDER = "planet_visuals";
    private static volatile List<PlanetVisual> cachedPlanets;

    private PlanetSkyRenderer() {}

    @SubscribeEvent
    public static void renderPlanets(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) return;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || !minecraft.level.dimension().equals(SPACE_DIMENSION)) return;
        PoseStack poseStack = event.getPoseStack();
        if (poseStack == null) return;

        List<PlanetVisual> planets = getPlanets(minecraft);
        if (planets.isEmpty()) return;

        Camera camera = event.getCamera();
        Vec3 cameraPosition = camera.getPosition();
        MultiBufferSource.BufferSource buffers = minecraft.renderBuffers().bufferSource();

        // Draw each planet as a camera-facing textured quad at its configured world position.
        // Coordinates in the data files are deliberately clustered around Y=800.
        for (PlanetVisual planet : planets) {
            ResourceLocation texture = planet.texture;
            RenderType renderType = RenderType.entityCutoutNoCull(texture);
            VertexConsumer vertices = buffers.getBuffer(renderType);
            poseStack.pushPose();
            poseStack.translate(
                    planet.x - cameraPosition.x,
                    planet.y - cameraPosition.y,
                    planet.z - cameraPosition.z
            );
            poseStack.mulPose(camera.rotation());
            PoseStack.Pose pose = poseStack.last();
            float half = planet.size * 0.5F;
            int red = (planet.tint >> 16) & 255;
            int green = (planet.tint >> 8) & 255;
            int blue = planet.tint & 255;

            // Two triangles, with the texture mapped across the full square.
            vertex(vertices, pose, -half, -half, 0, 0, 1, red, green, blue);
            vertex(vertices, pose, half, -half, 0, 1, 1, red, green, blue);
            vertex(vertices, pose, half, half, 0, 1, 0, red, green, blue);
            vertex(vertices, pose, -half, -half, 0, 0, 1, red, green, blue);
            vertex(vertices, pose, half, half, 0, 1, 0, red, green, blue);
            vertex(vertices, pose, -half, half, 0, 0, 0, red, green, blue);
            poseStack.popPose();
            buffers.endBatch(renderType);
        }
    }

    private static void vertex(VertexConsumer consumer, PoseStack.Pose pose,
                               float x, float y, float z, float u, float v,
                               int red, int green, int blue) {
        consumer.addVertex(pose, x, y, z)
                .setColor(red, green, blue, 255)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(0x00F000F0)
                .setNormal(pose, 0.0F, 0.0F, 1.0F);
    }

    private static List<PlanetVisual> getPlanets(Minecraft minecraft) {
        List<PlanetVisual> current = cachedPlanets;
        if (current != null) return current;
        synchronized (PlanetSkyRenderer.class) {
            if (cachedPlanets != null) return cachedPlanets;
            List<PlanetVisual> loaded = new ArrayList<>();
            try {
                Map<ResourceLocation, net.minecraft.server.packs.resources.Resource> resources =
                        minecraft.getResourceManager().listResources(DATA_FOLDER,
                                id -> id.getPath().endsWith(".json"));
                for (Map.Entry<ResourceLocation, net.minecraft.server.packs.resources.Resource> entry : resources.entrySet()) {
                    try (InputStreamReader reader = new InputStreamReader(entry.getValue().open(), StandardCharsets.UTF_8)) {
                        String json = new String(readerToBytes(reader), StandardCharsets.UTF_8);
                        String textureText = stringField(json, "texture", null);
                        if (textureText == null) continue;
                        ResourceLocation texture = parseLocation(textureText);
                        String tintText = stringField(json, "tint", "#FFFFFF");
                        int tint = (int) Long.parseLong(tintText.replace("#", ""), 16);
                        loaded.add(new PlanetVisual(
                                stringField(json, "name", entry.getKey().getPath()),
                                texture,
                                positionNumberField(json, "x", 0.0),
                                positionNumberField(json, "y", 800.0),
                                positionNumberField(json, "z", 600.0),
                                (float) numberField(json, "size", 24.0),
                                tint
                        ));
                    } catch (Exception fileError) {
                        System.err.println("[BYTSN Planet Render] Skipping invalid planet data " + entry.getKey() + ": " + fileError.getMessage());
                    }
                }
                loaded.sort(Comparator.comparing(p -> p.name));
            } catch (Exception loadError) {
                System.err.println("[BYTSN Planet Render] Could not load planet_visuals JSON: " + loadError.getMessage());
            }
            cachedPlanets = List.copyOf(loaded);
            System.out.println("[BYTSN Planet Render] Loaded " + cachedPlanets.size() + " planet visuals.");
            return cachedPlanets;
        }
    }

    private static byte[] readerToBytes(InputStreamReader reader) throws java.io.IOException {
        StringBuilder builder = new StringBuilder();
        char[] chars = new char[2048];
        int count;
        while ((count = reader.read(chars)) != -1) builder.append(chars, 0, count);
        return builder.toString().getBytes(StandardCharsets.UTF_8);
    }

    private static String stringField(String json, String field, String fallback) {
        Matcher matcher = Pattern.compile("\"" + Pattern.quote(field) + "\"\\s*:\\s*\"([^\"]*)\"").matcher(json);
        return matcher.find() ? matcher.group(1) : fallback;
    }

    private static double positionNumberField(String json, String field, double fallback) {
        // Planet data stores coordinates inside "position": { "x": ..., "y": ..., "z": ... }.
        Matcher position = Pattern.compile("\"position\"\\s*:\\s*\\{([^}]*)}").matcher(json);
        if (position.find()) {
            Matcher value = Pattern.compile("\"" + Pattern.quote(field) + "\"\\s*:\\s*(-?\\d+(?:\\.\\d+)?)").matcher(position.group(1));
            if (value.find()) return Double.parseDouble(value.group(1));
        }
        // Also accept top-level coordinates for backwards-compatible hand-authored JSON.
        return numberField(json, field, fallback);
    }

    private static double numberField(String json, String field, double fallback) {
        Matcher matcher = Pattern.compile("\"" + Pattern.quote(field) + "\"\\s*:\\s*(-?\\d+(?:\\.\\d+)?)").matcher(json);
        return matcher.find() ? Double.parseDouble(matcher.group(1)) : fallback;
    }

    private static ResourceLocation parseLocation(String text) {
        int colon = text.indexOf(':');
        if (colon < 0) return ResourceLocation.fromNamespaceAndPath("bytsn_planet_render", text);
        return ResourceLocation.fromNamespaceAndPath(text.substring(0, colon), text.substring(colon + 1));
    }

    private record PlanetVisual(String name, ResourceLocation texture,
                                double x, double y, double z, float size, int tint) {}
}
