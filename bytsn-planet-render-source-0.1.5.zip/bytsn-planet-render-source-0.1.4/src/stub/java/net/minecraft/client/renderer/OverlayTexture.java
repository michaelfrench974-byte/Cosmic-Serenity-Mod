package net.minecraft.client.renderer; public class OverlayTexture { public static final int NO_OVERLAY=0; }
