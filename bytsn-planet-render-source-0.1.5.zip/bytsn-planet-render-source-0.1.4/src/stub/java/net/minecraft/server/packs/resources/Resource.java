package net.minecraft.server.packs.resources; import java.io.*; public class Resource { public InputStream open() throws IOException{return null;} }
