package net.minecraft.server.packs.resources;

import java.util.Map;
import java.util.function.Predicate;
import net.minecraft.resources.ResourceLocation;

/** Mirrors the Minecraft 1.21.1 API shape: ResourceManager is an interface. */
public interface ResourceManager {
    Map<ResourceLocation, Resource> listResources(String directory, Predicate<ResourceLocation> filter);
}
