# BYTSN Planet Render — prototype 0.1.5

Target: Minecraft Java 1.21.1 / NeoForge 21.1.x / BYTSN 1.0.0+

This is an early rendering prototype, not a finished orbital simulation. It adds a blank dimension `bytsn_planet_render:space` and draws the nine supplied planet textures as camera-facing textured quads. Planet positions are loaded from `data/bytsn_planet_render/planet_visuals/*.json` and arranged around Y=800.

## 0.1.5 fix

Corrected the compile-time API stub so `net.minecraft.server.packs.resources.ResourceManager` is treated as an interface, matching Minecraft 1.21.1. This changes the compiled call to `invokeinterface` rather than `invokevirtual`, addressing the reported `IncompatibleClassChangeError`.

## Install/test

1. Remove all older `bytsn-planet-render-*.jar` versions.
2. Install only `bytsn-planet-render-0.1.5.jar` beside Beyond The Stars (`bytsn`).
3. Launch Minecraft 1.21.1 with NeoForge 21.1.x.
4. In a world, use `/execute in bytsn_planet_render:space run tp @s 0 800 0`.
5. Look toward positive Z.

## Important build note

This artifact was compiled against local API stubs because the environment could not fetch NeoForge Gradle dependencies. The specific ResourceManager interface bytecode mismatch is corrected and verified with `javap`, but this is not a full NeoForge Gradle build or an in-game launch test. Other API/runtime issues may remain. Sable compatibility is not yet tested.


Version 0.1.5 fixes two visibility issues in the prototype: the previous AFTER_SKY stage supplies a null PoseStack in NeoForge 1.21.1, and planet coordinates are nested inside the JSON `position` object. The renderer now runs at AFTER_ENTITIES and reads the nested coordinates.


Version 0.1.5 correction: `monster_spawn_light_level` now uses the Minecraft 1.21.1 IntProvider codec shape (`type`, `min_inclusive`, `max_inclusive`) without an extra `value` wrapper.
